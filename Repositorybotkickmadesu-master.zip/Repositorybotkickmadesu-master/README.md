# Repositorybotkickmadesu
Cara membuat repositorybotkickmadesu baru dengan github
